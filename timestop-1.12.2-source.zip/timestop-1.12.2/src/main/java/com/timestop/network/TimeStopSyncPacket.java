package com.timestop.network;

import com.timestop.core.ClientTimeStopManager;
import com.timestop.core.TimeMode;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.UUID;

public class TimeStopSyncPacket implements IMessage {
    private boolean active;
    private int duration;
    @Nullable
    private UUID initiator;
    private TimeMode mode;

    // Required no-arg constructor for the network layer.
    public TimeStopSyncPacket() {
    }

    public TimeStopSyncPacket(boolean active, int duration, @Nullable UUID initiator, TimeMode mode) {
        this.active = active;
        this.duration = duration;
        this.initiator = initiator;
        this.mode = mode;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        active = buf.readBoolean();
        duration = buf.readInt();
        boolean hasInitiator = buf.readBoolean();
        initiator = hasInitiator ? new UUID(buf.readLong(), buf.readLong()) : null;
        mode = TimeMode.values()[buf.readInt()];
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeBoolean(active);
        buf.writeInt(duration);
        buf.writeBoolean(initiator != null);
        if (initiator != null) {
            buf.writeLong(initiator.getMostSignificantBits());
            buf.writeLong(initiator.getLeastSignificantBits());
        }
        buf.writeInt(mode.ordinal());
    }

    @SideOnly(Side.CLIENT)
    public static class Handler implements IMessageHandler<TimeStopSyncPacket, IMessage> {
        @Override
        public IMessage onMessage(TimeStopSyncPacket message, MessageContext ctx) {
            Minecraft.getMinecraft().addScheduledTask(() ->
                    ClientTimeStopManager.handleSync(message.active, message.duration, message.initiator, message.mode));
            return null;
        }
    }
}
