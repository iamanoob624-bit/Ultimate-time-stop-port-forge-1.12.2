package com.timestop.network;

import com.timestop.core.CooldownManager;
import com.timestop.core.TimeMode;
import com.timestop.core.TimeStopManager;
import com.timestop.item.ChronosWatchItem;
import com.timestop.item.CreativeWatchItem;
import com.timestop.item.ModItems;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class ToggleTimeStopPacket implements IMessage {

    public ToggleTimeStopPacket() {
    }

    @Override
    public void fromBytes(ByteBuf buf) {
    }

    @Override
    public void toBytes(ByteBuf buf) {
    }

    public static class Handler implements IMessageHandler<ToggleTimeStopPacket, IMessage> {
        @Override
        public IMessage onMessage(ToggleTimeStopPacket message, MessageContext ctx) {
            EntityPlayerMP player = ctx.getServerHandler().player;
            FMLCommonHandler.instance().getMinecraftServerInstance().addScheduledTask(() -> handle(player));
            return null;
        }

        private void handle(EntityPlayerMP player) {
            if (!(player.world instanceof WorldServer)) return;
            WorldServer serverLevel = (WorldServer) player.world;

            if (TimeStopManager.isTimeStopped(serverLevel)) {
                TimeStopManager.resumeTime(serverLevel);
                return;
            }

            ItemStack creativeWatch = findItem(player, ModItems.CREATIVE_WATCH);
            ItemStack survivalWatch = findItem(player, ModItems.CHRONOS_WATCH);

            if (player.capabilities.isCreativeMode || !creativeWatch.isEmpty()) {
                TimeMode mode = !creativeWatch.isEmpty() ? CreativeWatchItem.getMode(creativeWatch) : TimeMode.TIME_STOP;
                TimeStopManager.startTimeStop(serverLevel, player, 0, mode);
            } else if (!survivalWatch.isEmpty()) {
                if (CooldownManager.isOnCooldown(player, ModItems.CHRONOS_WATCH)) {
                    player.sendStatusMessage(new TextComponentString("\u00A7cYour Chronos Watch is recharging!"), true);
                    return;
                }
                TimeMode mode = ChronosWatchItem.getMode(survivalWatch);
                TimeStopManager.startTimeStop(serverLevel, player, ChronosWatchItem.DEFAULT_SURVIVAL_TICKS, mode);
            } else {
                player.sendStatusMessage(new TextComponentString("\u00A7cYou need a Chronos Pocket Watch to control time!"), true);
            }
        }

        private static ItemStack findItem(EntityPlayerMP player, net.minecraft.item.Item target) {
            if (player.getHeldItemMainhand().getItem() == target) {
                return player.getHeldItemMainhand();
            }
            if (player.getHeldItemOffhand().getItem() == target) {
                return player.getHeldItemOffhand();
            }
            for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                ItemStack stack = player.inventory.getStackInSlot(i);
                if (!stack.isEmpty() && stack.getItem() == target) {
                    return stack;
                }
            }
            return ItemStack.EMPTY;
        }
    }
}
