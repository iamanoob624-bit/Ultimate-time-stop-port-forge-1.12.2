package com.timestop.network;

import com.timestop.TimeStopMod;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class ModMessages {
    public static SimpleNetworkWrapper INSTANCE;
    private static int packetId = 0;

    private static int nextId() {
        return packetId++;
    }

    public static void register() {
        INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel(TimeStopMod.MOD_ID);

        INSTANCE.registerMessage(TimeStopSyncPacket.Handler.class, TimeStopSyncPacket.class, nextId(), Side.CLIENT);
        INSTANCE.registerMessage(ToggleTimeStopPacket.Handler.class, ToggleTimeStopPacket.class, nextId(), Side.SERVER);
    }

    public static void sendToServer(IMessage message) {
        INSTANCE.sendToServer(message);
    }

    public static void sendToAll(IMessage message) {
        INSTANCE.sendToAll(message);
    }
}
