package com.timestop.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class TemporalDamageBuffer {
    public static class DamageRecord {
        public float totalDamage = 0.0F;
        public Vec3d totalKnockback = Vec3d.ZERO;
        public DamageSource lastDamageSource = null;
        public int hitCount = 0;

        public void addHit(float amount, Vec3d knockback, DamageSource source) {
            this.totalDamage += amount;
            this.totalKnockback = this.totalKnockback.add(knockback);
            this.lastDamageSource = source;
            this.hitCount++;
        }
    }

    private static final Map<UUID, DamageRecord> records = new ConcurrentHashMap<>();
    private static final Map<UUID, EntityLivingBase> victimEntities = new ConcurrentHashMap<>();
    private static WeakReference<WorldServer> lastKnownLevel = new WeakReference<>(null);

    public static void recordHit(EntityLivingBase victim, float amount, DamageSource source) {
        records.computeIfAbsent(victim.getUniqueID(), k -> new DamageRecord());
        victimEntities.put(victim.getUniqueID(), victim);

        if (victim.world instanceof WorldServer) {
            lastKnownLevel = new WeakReference<>((WorldServer) victim.world);
        }

        Vec3d knockback;
        Entity attacker = source.getTrueSource();
        if (attacker != null) {
            Vec3d diff = new Vec3d(victim.posX, victim.posY, victim.posZ)
                    .subtract(new Vec3d(attacker.posX, attacker.posY, attacker.posZ)).normalize();
            knockback = new Vec3d(diff.x * 0.6, 0.4, diff.z * 0.6);
        } else {
            knockback = new Vec3d(0, 0.3, 0);
        }

        DamageRecord record = records.get(victim.getUniqueID());
        record.addHit(amount, knockback, source);

        // Immediate visual & auditory feedback during frozen time
        victim.hurtTime = 10;
        victim.maxHurtTime = 10;
        victim.hurtResistantTime = 0; // allow subsequent hits to register during time stop

        if (victim.world instanceof WorldServer) {
            WorldServer serverLevel = (WorldServer) victim.world;
            serverLevel.spawnParticle(EnumParticleTypes.CRIT,
                    victim.posX, victim.posY + victim.height * 0.5, victim.posZ,
                    15, 0.2, 0.3, 0.2, 0.1);
            serverLevel.playSound(null, victim.posX, victim.posY, victim.posZ,
                    SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.2F, 0.7F);
        }
    }

    public static boolean hasRecord(UUID uuid) {
        return records.containsKey(uuid);
    }

    public static void dischargeAll(WorldServer world) {
        for (Map.Entry<UUID, DamageRecord> entry : records.entrySet()) {
            UUID victimUuid = entry.getKey();
            DamageRecord record = entry.getValue();
            EntityLivingBase victim = victimEntities.get(victimUuid);

            if (victim == null || !victim.isEntityAlive()) {
                Entity entity = world.getEntityFromUuid(victimUuid);
                if (entity instanceof EntityLivingBase) {
                    victim = (EntityLivingBase) entity;
                }
            }

            if (victim != null && victim.isEntityAlive()) {
                victim.hurtResistantTime = 0;

                DamageSource source = record.lastDamageSource != null ? record.lastDamageSource : DamageSource.GENERIC;
                victim.attackEntityFrom(source, record.totalDamage);

                Vec3d finalKb = record.totalKnockback;
                double maxSpeed = 4.0;
                if (finalKb.lengthVector() > maxSpeed) {
                    finalKb = finalKb.normalize().scale(maxSpeed);
                }
                victim.motionX += finalKb.x;
                victim.motionY += finalKb.y;
                victim.motionZ += finalKb.z;
                victim.velocityChanged = true;

                world.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE,
                        victim.posX, victim.posY + victim.height * 0.5, victim.posZ,
                        1, 0, 0, 0, 0);
                world.playSound(null, victim.posX, victim.posY, victim.posZ,
                        SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 1.0F, 1.5F);
            }
        }

        records.clear();
        victimEntities.clear();
    }

    @Nullable
    public static WorldServer getLastKnownLevel() {
        return lastKnownLevel.get();
    }
}
