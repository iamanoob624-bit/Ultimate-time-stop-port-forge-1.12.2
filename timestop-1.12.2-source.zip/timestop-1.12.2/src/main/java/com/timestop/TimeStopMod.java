package com.timestop;

import com.timestop.command.TimeStopCommand;
import com.timestop.network.ModMessages;
import com.timestop.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import org.apache.logging.log4j.Logger;

@Mod(modid = TimeStopMod.MOD_ID, name = TimeStopMod.NAME, version = TimeStopMod.VERSION,
        acceptedMinecraftVersions = "[1.12.2]")
public class TimeStopMod {
    public static final String MOD_ID = "timestop";
    public static final String NAME = "Hardcore Time Stop";
    public static final String VERSION = "1.0.0";
    public static Logger LOGGER;

    @SidedProxy(clientSide = "com.timestop.proxy.ClientProxy", serverSide = "com.timestop.proxy.CommonProxy")
    public static CommonProxy proxy;

    // com.timestop.item.ModItems and com.timestop.event.ServerEventHandler register
    // themselves via @Mod.EventBusSubscriber; nothing to do for them here.

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER = event.getModLog();
        LOGGER.info("[TimeStop] Hardcore Time Stop (1.12.2 port) loading...");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        ModMessages.register();
        proxy.registerModels();
        proxy.clientInit();
    }

    @Mod.EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        event.registerServerCommand(new TimeStopCommand());
    }
}
