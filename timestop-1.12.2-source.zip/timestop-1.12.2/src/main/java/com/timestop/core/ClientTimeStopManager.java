package com.timestop.core;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

import javax.annotation.Nullable;
import java.util.UUID;

public class ClientTimeStopManager {
    private static boolean clientTimeStopped = false;
    private static int clientRemainingTicks = 0;
    private static int clientTotalDuration = 0;
    @Nullable
    private static UUID clientInitiatorUuid = null;
    private static TimeMode clientMode = TimeMode.TIME_STOP;
    private static boolean shaderActive = false;

    // Porting note: 1.20.1 used "shaders/post/desaturate.json". That shader isn't part of
    // vanilla 1.12.2's asset set, so this uses "nausea.json" (bundled with vanilla) as a
    // stand-in visual cue. Swap for any vanilla shader in assets/minecraft/shaders/post/,
    // or drop your own into your resources to match the original look exactly.
    private static final ResourceLocation TIME_STOP_SHADER = new ResourceLocation("minecraft", "shaders/post/nausea.json");

    public static boolean isTimeStopped() {
        return clientTimeStopped;
    }

    public static TimeMode getCurrentMode() {
        return clientMode;
    }

    public static boolean isEntityExempt(Entity entity) {
        if (!clientTimeStopped) return true;

        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            if (player.capabilities.isCreativeMode || player.isSpectator()) {
                return true;
            }
            if (clientInitiatorUuid != null && player.getUniqueID().equals(clientInitiatorUuid)) {
                return true;
            }
        }

        return false;
    }

    public static void handleSync(boolean active, int duration, @Nullable UUID initiator, TimeMode mode) {
        clientTimeStopped = active;
        clientTotalDuration = duration;
        clientRemainingTicks = duration;
        clientInitiatorUuid = initiator;
        clientMode = mode;

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world != null) {
            if (active && mode == TimeMode.TIME_STOP) {
                applyShader();
            } else {
                removeShader();
            }
        }
    }

    public static void clientTick() {
        if (clientTimeStopped && clientRemainingTicks > 0) {
            clientRemainingTicks--;
        }
    }

    public static void applyShader() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.entityRenderer != null && !shaderActive) {
            try {
                mc.entityRenderer.loadShader(TIME_STOP_SHADER);
                shaderActive = true;
            } catch (Exception ignored) {
            }
        }
    }

    public static void removeShader() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.entityRenderer != null && shaderActive) {
            try {
                mc.entityRenderer.stopUseShader();
                shaderActive = false;
            } catch (Exception ignored) {
            }
        }
    }

    public static int getRemainingTicks() {
        return clientRemainingTicks;
    }

    public static int getTotalDuration() {
        return clientTotalDuration;
    }
}
