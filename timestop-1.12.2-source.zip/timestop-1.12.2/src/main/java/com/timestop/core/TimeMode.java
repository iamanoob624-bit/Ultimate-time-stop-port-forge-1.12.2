package com.timestop.core;

public enum TimeMode {
    TIME_STOP("Time Stop", "\u00A76\u00A7lTIME STOP", "\u00A7eFreezes all time, entities, and projectiles completely."),
    SLOW_MOTION("Slow Motion", "\u00A79\u00A7lSLOW MOTION", "\u00A7bSlows the entire world to 25% speed."),
    MATRIX("Matrix", "\u00A7a\u00A7lMATRIX", "\u00A72World slows down while you move at hyper-speed."),
    FAST_FORWARD("Fast Forward", "\u00A7c\u00A7lFAST FORWARD", "\u00A74Accelerates entity updates, smelting, and crop growth.");

    private final String displayName;
    private final String formattedName;
    private final String description;

    TimeMode(String displayName, String formattedName, String description) {
        this.displayName = displayName;
        this.formattedName = formattedName;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public String getFormattedName() {
        return formattedName;
    }

    public String getDescription() {
        return description;
    }

    public TimeMode next() {
        TimeMode[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}
