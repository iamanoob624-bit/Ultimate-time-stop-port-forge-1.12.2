package com.timestop.core;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Minecraft 1.12.2 has no built-in per-item cooldown system (that API, ItemCooldowns,
 * was added in 1.13). This is a small stand-in: it tracks, per player+item, the world
 * time at which the cooldown expires. It is memory-only (not persisted across a
 * server restart), which mirrors vanilla 1.13+ cooldown behavior closely enough for
 * this mod's purposes.
 */
public class CooldownManager {
    private static final Map<UUID, Map<Item, Long>> COOLDOWNS = new ConcurrentHashMap<>();

    public static void setCooldown(EntityPlayer player, Item item, int ticks) {
        long expiry = player.world.getTotalWorldTime() + ticks;
        COOLDOWNS.computeIfAbsent(player.getUniqueID(), k -> new ConcurrentHashMap<>()).put(item, expiry);
    }

    public static boolean isOnCooldown(EntityPlayer player, Item item) {
        Map<Item, Long> playerCooldowns = COOLDOWNS.get(player.getUniqueID());
        if (playerCooldowns == null) return false;
        Long expiry = playerCooldowns.get(item);
        if (expiry == null) return false;
        if (player.world.getTotalWorldTime() >= expiry) {
            playerCooldowns.remove(item);
            return false;
        }
        return true;
    }

    public static void clearCooldown(EntityPlayer player, Item item) {
        Map<Item, Long> playerCooldowns = COOLDOWNS.get(player.getUniqueID());
        if (playerCooldowns != null) {
            playerCooldowns.remove(item);
        }
    }
}
