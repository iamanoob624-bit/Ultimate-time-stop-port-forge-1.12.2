package com.timestop.core;

import com.timestop.combat.TemporalDamageBuffer;
import com.timestop.item.ModItems;
import com.timestop.network.ModMessages;
import com.timestop.network.TimeStopSyncPacket;
import net.minecraft.entity.Entity;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.WorldServer;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Server-side authority for time-stop state.
 *
 * Porting note: the original 1.20.1 edition used Mixin to change the actual
 * millisecond length of a server tick (MinecraftServerMixin) so that SLOW_MOTION /
 * MATRIX / FAST_FORWARD were true whole-engine speed changes. 1.12.2 Forge has no
 * supported way to do that without a coremod/ASM patch of MinecraftServer's private
 * tick loop, so this port does not attempt it. TIME_STOP (the mod's flagship mode) is
 * fully ported via events instead of mixins - see event/ServerEventHandler. The other
 * three modes are approximated with a "skip ticks" / "extra ticks" strategy instead of
 * a true tick-rate change; see ServerEventHandler for details and the README for the
 * trade-offs.
 */
public class TimeStopManager {
    private static boolean timeStopped = false;
    private static int remainingTicks = 0;
    private static int totalDuration = 0;
    @Nullable
    private static UUID initiatorUuid = null;
    private static TimeMode currentMode = TimeMode.TIME_STOP;
    private static final Set<UUID> exemptPlayers = ConcurrentHashMap.newKeySet();

    // Suspended projectiles: entity UUID -> stored velocity, plus a reference to find them again.
    private static final Map<UUID, Vec3d> suspendedProjectiles = new ConcurrentHashMap<>();
    private static final Map<UUID, Entity> projectileEntities = new ConcurrentHashMap<>();

    private static final UUID MATRIX_SPEED_UUID = UUID.fromString("c0a80101-0000-0000-0000-000000000001");
    private static final UUID MATRIX_ATTACK_UUID = UUID.fromString("c0a80101-0000-0000-0000-000000000002");
    // AttributeModifier.Operation is an int in 1.12.2: 0 = ADD, 1 = MULTIPLY_BASE (add %), 2 = MULTIPLY_TOTAL
    private static final AttributeModifier MATRIX_SPEED_MOD =
            new AttributeModifier(MATRIX_SPEED_UUID, "Matrix Speed", 3.0D, 2);
    private static final AttributeModifier MATRIX_ATTACK_MOD =
            new AttributeModifier(MATRIX_ATTACK_UUID, "Matrix Attack Speed", 3.0D, 2);

    public static boolean isGlobalTimeStopped() {
        return timeStopped;
    }

    public static boolean isTimeStopped(@Nullable net.minecraft.world.World world) {
        return timeStopped;
    }

    public static TimeMode getCurrentMode() {
        return currentMode;
    }

    /** How many world ticks out of every 4 should actually execute for slow modes. */
    public static boolean shouldExecuteSlowTick(long totalWorldTime) {
        if (!timeStopped) return true;
        if (currentMode == TimeMode.SLOW_MOTION || currentMode == TimeMode.MATRIX) {
            return totalWorldTime % 4 == 0; // ~5 executed ticks/sec instead of 20
        }
        return true;
    }

    /** How many extra passes FAST_FORWARD logic should run this tick (on top of the normal one). */
    public static int getFastForwardExtraPasses() {
        if (timeStopped && currentMode == TimeMode.FAST_FORWARD) {
            return 4; // 1 normal + 4 extra = 5x
        }
        return 0;
    }

    public static boolean isEntityExempt(Entity entity) {
        if (!timeStopped) return true;

        if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer) entity;
            if (player.capabilities.isCreativeMode || player.isSpectator()) {
                return true;
            }
            if (initiatorUuid != null && player.getUniqueID().equals(initiatorUuid)) {
                return true;
            }
            return exemptPlayers.contains(player.getUniqueID());
        }

        return false;
    }

    public static void addExemptPlayer(UUID uuid) {
        exemptPlayers.add(uuid);
    }

    public static void removeExemptPlayer(UUID uuid) {
        exemptPlayers.remove(uuid);
    }

    public static boolean isPlayerExempt(UUID uuid) {
        return (initiatorUuid != null && initiatorUuid.equals(uuid)) || exemptPlayers.contains(uuid);
    }

    public static void startTimeStop(WorldServer world, @Nullable EntityPlayer initiator, int durationTicks, TimeMode mode) {
        if (timeStopped) return;

        timeStopped = true;
        totalDuration = durationTicks;
        remainingTicks = durationTicks;
        currentMode = mode;
        initiatorUuid = initiator != null ? initiator.getUniqueID() : null;

        if (mode == TimeMode.MATRIX && initiator != null) {
            applyMatrixAttributes(initiator);
        }

        if (initiator != null) {
            double x = initiator.posX, y = initiator.posY, z = initiator.posZ;
            switch (mode) {
                case TIME_STOP:
                    playSound(world, x, y, z, SoundEvents.ENTITY_ENDERDRAGON_GROWL, 2.0F, 0.5F);
                    playSound(world, x, y, z, SoundEvents.BLOCK_BEACON_DEACTIVATE, 2.5F, 0.6F);
                    break;
                case SLOW_MOTION:
                    playSound(world, x, y, z, SoundEvents.ENTITY_GUARDIAN_AMBIENT, 2.0F, 0.5F);
                    break;
                case MATRIX:
                    playSound(world, x, y, z, SoundEvents.ENTITY_ENDEREYE_DEATH, 2.0F, 0.4F);
                    playSound(world, x, y, z, SoundEvents.ENTITY_WITHER_AMBIENT, 2.0F, 1.2F);
                    break;
                case FAST_FORWARD:
                    playSound(world, x, y, z, SoundEvents.BLOCK_PORTAL_TRIGGER, 1.5F, 1.8F);
                    break;
            }
            initiator.sendStatusMessage(new TextComponentString(
                    "\u00A76[Temporal Engine] " + mode.getFormattedName() + " \u00A7aactivated!"), true);
        } else {
            for (Object p : world.playerEntities) {
                EntityPlayer player = (EntityPlayer) p;
                playSound(world, player.posX, player.posY, player.posZ, SoundEvents.BLOCK_BEACON_DEACTIVATE, 2.5F, 0.6F);
            }
        }

        ModMessages.sendToAll(new TimeStopSyncPacket(true, durationTicks, initiatorUuid, mode));
    }

    public static void startTimeStop(WorldServer world, @Nullable EntityPlayer initiator, int durationTicks) {
        startTimeStop(world, initiator, durationTicks, TimeMode.TIME_STOP);
    }

    public static void resumeTime(WorldServer world) {
        if (!timeStopped) return;

        timeStopped = false;
        remainingTicks = 0;
        totalDuration = 0;

        if (currentMode == TimeMode.TIME_STOP) {
            TemporalDamageBuffer.dischargeAll(world);
            resumeProjectiles(world);
        }

        if (initiatorUuid != null) {
            EntityPlayerMP initiator = world.getMinecraftServer().getPlayerList().getPlayerByUUID(initiatorUuid);
            if (initiator != null) {
                removeMatrixAttributes(initiator);

                if (!initiator.capabilities.isCreativeMode) {
                    CooldownManager.setCooldown(initiator, ModItems.CHRONOS_WATCH, 300); // 15s
                }
                initiator.sendStatusMessage(new TextComponentString(
                        "\u00A7b\u00A7l[Temporal Engine] \u00A7fTime normalized. Cooldown started."), true);
            }
        }

        for (Object p : world.playerEntities) {
            EntityPlayer player = (EntityPlayer) p;
            playSound(world, player.posX, player.posY, player.posZ, SoundEvents.BLOCK_BEACON_ACTIVATE, 2.0F, 1.2F);
            playSound(world, player.posX, player.posY, player.posZ, SoundEvents.BLOCK_END_PORTAL_SPAWN, 1.0F, 1.8F);
        }

        initiatorUuid = null;
        currentMode = TimeMode.TIME_STOP;

        ModMessages.sendToAll(new TimeStopSyncPacket(false, 0, null, TimeMode.TIME_STOP));
    }

    public static void toggleTimeStop(WorldServer world, EntityPlayer player, int durationTicks, TimeMode mode) {
        if (timeStopped) {
            resumeTime(world);
        } else {
            startTimeStop(world, player, durationTicks, mode);
        }
    }

    /** Call once per server tick (END phase). Ports TimeStopManager#serverTick. */
    public static void serverTick(WorldServer anyLoadedWorld) {
        if (!timeStopped) return;

        if (remainingTicks > 0) {
            remainingTicks--;
            if (remainingTicks <= 0) {
                WorldServer level = TemporalDamageBuffer.getLastKnownLevel();
                if (level == null) level = anyLoadedWorld;
                if (level != null) {
                    resumeTime(level);
                } else {
                    timeStopped = false;
                    initiatorUuid = null;
                    ModMessages.sendToAll(new TimeStopSyncPacket(false, 0, null, TimeMode.TIME_STOP));
                }
            }
        }
    }

    private static void applyMatrixAttributes(EntityPlayer player) {
        IAttributeInstance speed = player.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(MATRIX_SPEED_UUID) == null) {
            speed.applyModifier(MATRIX_SPEED_MOD);
        }
        IAttributeInstance attack = player.getEntityAttribute(SharedMonsterAttributes.ATTACK_SPEED);
        if (attack != null && attack.getModifier(MATRIX_ATTACK_UUID) == null) {
            attack.applyModifier(MATRIX_ATTACK_MOD);
        }
    }

    private static void removeMatrixAttributes(EntityPlayer player) {
        IAttributeInstance speed = player.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED);
        if (speed != null && speed.getModifier(MATRIX_SPEED_UUID) != null) {
            speed.removeModifier(MATRIX_SPEED_MOD);
        }
        IAttributeInstance attack = player.getEntityAttribute(SharedMonsterAttributes.ATTACK_SPEED);
        if (attack != null && attack.getModifier(MATRIX_ATTACK_UUID) != null) {
            attack.removeModifier(MATRIX_ATTACK_MOD);
        }
    }

    public static void registerSuspendedProjectile(Entity projectile, Vec3d originalVelocity) {
        if (!timeStopped || currentMode != TimeMode.TIME_STOP) return;
        suspendedProjectiles.put(projectile.getUniqueID(), originalVelocity);
        projectileEntities.put(projectile.getUniqueID(), projectile);

        projectile.motionX = 0;
        projectile.motionY = 0;
        projectile.motionZ = 0;
        projectile.setNoGravity(true);
    }

    private static void resumeProjectiles(WorldServer world) {
        for (Map.Entry<UUID, Vec3d> entry : suspendedProjectiles.entrySet()) {
            Entity projectile = projectileEntities.get(entry.getKey());
            if (projectile != null && !projectile.isDead) {
                Vec3d velocity = entry.getValue();
                projectile.setNoGravity(false);
                projectile.motionX = velocity.x;
                projectile.motionY = velocity.y;
                projectile.motionZ = velocity.z;
                world.spawnParticle(EnumParticleTypes.CRIT, projectile.posX, projectile.posY, projectile.posZ,
                        10, 0.1, 0.1, 0.1, 0.15);
                playSound(world, projectile.posX, projectile.posY, projectile.posZ, SoundEvents.ENTITY_ARROW_SHOOT, 1.2F, 1.2F);
            }
        }
        suspendedProjectiles.clear();
        projectileEntities.clear();
    }

    public static boolean isSuspendedProjectile(UUID uuid) {
        return suspendedProjectiles.containsKey(uuid);
    }

    private static void playSound(WorldServer world, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        world.playSound(null, x, y, z, sound, SoundCategory.PLAYERS, volume, pitch);
    }

    public static int getRemainingTicks() {
        return remainingTicks;
    }

    public static int getTotalDuration() {
        return totalDuration;
    }

    @Nullable
    public static UUID getInitiatorUuid() {
        return initiatorUuid;
    }
}
