package com.timestop.item;

import com.timestop.TimeStopMod;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = TimeStopMod.MOD_ID)
public class ModItems {

    public static final CreativeTabs TIME_STOP_TAB = new CreativeTabs("timestop_tab") {
        @Override
        public ItemStack createIcon() {
            return new ItemStack(CREATIVE_WATCH);
        }
    };

    public static final Item CHRONOS_WATCH = new ChronosWatchItem()
            .setRegistryName(TimeStopMod.MOD_ID, "chronos_watch")
            .setTranslationKey(TimeStopMod.MOD_ID + ".chronos_watch")
            .setMaxStackSize(1)
            .setMaxDamage(100)
            .setCreativeTab(TIME_STOP_TAB);

    public static final Item CREATIVE_WATCH = new CreativeWatchItem()
            .setRegistryName(TimeStopMod.MOD_ID, "creative_watch")
            .setTranslationKey(TimeStopMod.MOD_ID + ".creative_watch")
            .setMaxStackSize(1)
            .setCreativeTab(TIME_STOP_TAB);

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll(CHRONOS_WATCH, CREATIVE_WATCH);
    }

    public static void registerModels() {
        // Called from the client proxy only (client-side item model wiring).
        registerItemModel(CHRONOS_WATCH);
        registerItemModel(CREATIVE_WATCH);
    }

    private static void registerItemModel(Item item) {
        net.minecraftforge.client.model.ModelLoader.setCustomModelResourceLocation(item, 0,
                new net.minecraft.client.renderer.block.model.ModelResourceLocation(item.getRegistryName(), "inventory"));
    }
}
