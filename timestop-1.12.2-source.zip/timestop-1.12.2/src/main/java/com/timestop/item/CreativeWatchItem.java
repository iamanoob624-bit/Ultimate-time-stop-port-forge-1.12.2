package com.timestop.item;

import com.timestop.core.TimeMode;
import com.timestop.core.TimeStopManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.client.util.ITooltipFlag;

import javax.annotation.Nullable;
import java.util.List;

public class CreativeWatchItem extends Item {

    public static TimeMode getMode(ItemStack stack) {
        if (stack.hasTagCompound() && stack.getTagCompound().hasKey("TimeMode")) {
            try {
                return TimeMode.valueOf(stack.getTagCompound().getString("TimeMode"));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return TimeMode.TIME_STOP;
    }

    public static void setMode(ItemStack stack, TimeMode mode) {
        if (!stack.hasTagCompound()) {
            stack.setTagCompound(new NBTTagCompound());
        }
        stack.getTagCompound().setString("TimeMode", mode.name());
    }

    @Override
    public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand hand) {
        ItemStack stack = player.getHeldItem(hand);

        if (player.isSneaking()) {
            TimeMode current = getMode(stack);
            TimeMode next = current.next();
            setMode(stack, next);

            if (world.isRemote) {
                player.sendStatusMessage(new TextComponentString(
                        "\u00A7d[Mode Switched] " + next.getFormattedName() + " \u00A77- " + next.getDescription()), true);
            } else {
                world.playSound(null, player.posX, player.posY, player.posZ,
                        SoundEvents.UI_BUTTON_CLICK, SoundCategory.PLAYERS, 0.8F, 1.4F);
            }
            return new ActionResult<>(EnumActionResult.SUCCESS, stack);
        }

        if (!world.isRemote && world instanceof WorldServer) {
            WorldServer serverLevel = (WorldServer) world;
            if (TimeStopManager.isTimeStopped(serverLevel)) {
                TimeStopManager.resumeTime(serverLevel);
            } else {
                TimeMode mode = getMode(stack);
                TimeStopManager.startTimeStop(serverLevel, player, 0, mode); // indefinite
            }
        }

        return new ActionResult<>(EnumActionResult.SUCCESS, stack);
    }

    @Override
    public boolean hasEffect(ItemStack stack) {
        return true; // enchantment glint
    }

    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        TimeMode mode = getMode(stack);
        tooltip.add("\u00A7d\u00A7lInfinite Chronos Watch \u00A77(Creative)");
        tooltip.add("Selected Mode: " + mode.getFormattedName());
        tooltip.add("\u00A77Mode Info: " + mode.getDescription());
        tooltip.add("");
        tooltip.add("\u00A7eSneak + Right-click: \u00A7fCycle Temporal Mode");
        tooltip.add("\u00A7aRight-click: \u00A7fActivate / Stop Selected Mode");
        tooltip.add("\u00A7b\u2022 Unlimited Infinite Duration");
        tooltip.add("\u00A7b\u2022 Zero Cooldown");
    }
}
