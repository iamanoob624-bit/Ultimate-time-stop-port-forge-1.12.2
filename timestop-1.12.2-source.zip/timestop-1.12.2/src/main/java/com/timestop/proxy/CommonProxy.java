package com.timestop.proxy;

public class CommonProxy {
    public void registerModels() {
        // no-op on the dedicated server; overridden client-side
    }

    public void clientInit() {
        // no-op on the dedicated server; overridden client-side
    }
}
