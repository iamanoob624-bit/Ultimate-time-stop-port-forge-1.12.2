package com.timestop.proxy;

import com.timestop.client.ClientEventHandler;
import com.timestop.client.ClientKeyBindings;
import com.timestop.item.ModItems;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {
    @Override
    public void registerModels() {
        ModItems.registerModels();
    }

    @Override
    public void clientInit() {
        ClientKeyBindings.register();
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
    }
}
