package com.timestop.client;

import com.timestop.core.ClientTimeStopManager;
import com.timestop.core.TimeMode;
import com.timestop.network.ModMessages;
import com.timestop.network.ToggleTimeStopPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientEventHandler {

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        ClientTimeStopManager.clientTick();

        while (ClientKeyBindings.TIME_STOP_KEY.isPressed()) {
            ModMessages.sendToServer(new ToggleTimeStopPacket());
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        if (!ClientTimeStopManager.isTimeStopped()) return;

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer font = mc.fontRenderer;

        int remainingTicks = ClientTimeStopManager.getRemainingTicks();
        int totalDuration = ClientTimeStopManager.getTotalDuration();
        TimeMode mode = ClientTimeStopManager.getCurrentMode();

        int screenWidth = event.getResolution().getScaledWidth();
        int x = screenWidth / 2;
        int y = 20;

        String statusText;
        if (totalDuration <= 0) {
            statusText = mode.getFormattedName() + " \u00A77[ \u00A7e\u221E ACTIVE \u00A77]";
        } else {
            float seconds = remainingTicks / 20.0F;
            statusText = String.format("%s \u00A77[ \u00A7e%.1fs \u00A77]", mode.getFormattedName(), seconds);
        }

        int textWidth = font.getStringWidth(statusText);
        font.drawStringWithShadow(statusText, x - textWidth / 2.0F, y, 0xFFFFFF);

        if (totalDuration > 0) {
            int barWidth = 120;
            int barHeight = 4;
            int barX = x - barWidth / 2;
            int barY = y + 12;

            Gui.drawRect(barX - 1, barY - 1, barX + barWidth + 1, barY + barHeight + 1, 0x88000000);

            float progress = Math.max(0.0F, Math.min(1.0F, (float) remainingTicks / totalDuration));
            int filledWidth = (int) (barWidth * progress);
            int color;
            switch (mode) {
                case SLOW_MOTION:
                    color = 0xFF00B4D8;
                    break;
                case MATRIX:
                    color = 0xFF2EC4B6;
                    break;
                case FAST_FORWARD:
                    color = 0xFFFF0054;
                    break;
                default:
                    color = 0xFFFFD700;
                    break;
            }
            Gui.drawRect(barX, barY, barX + filledWidth, barY + barHeight, color);
        }
    }
}
