package com.timestop.client;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class ClientKeyBindings {
    public static final KeyBinding TIME_STOP_KEY = new KeyBinding(
            "key.timestop.toggle", Keyboard.KEY_V, "key.categories.timestop");

    public static void register() {
        ClientRegistry.registerKeyBinding(TIME_STOP_KEY);
    }
}
