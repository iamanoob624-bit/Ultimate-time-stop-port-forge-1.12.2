package com.timestop.event;

import com.timestop.TimeStopMod;
import com.timestop.combat.TemporalDamageBuffer;
import com.timestop.core.TimeMode;
import com.timestop.core.TimeStopManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Everything the 1.20.1 edition did with Mixins (ClientLevelMixin, LevelMixin,
 * ServerLevelMixin, LivingEntityMixin, ProjectileMixin, MinecraftServerMixin, ...) is
 * reimplemented here with plain Forge events, since 1.12.2 Forge has no built-in Mixin
 * support and bootstrapping one would need an extra coremod dependency.
 *
 * Strategy for TIME_STOP:
 *  - Living entities (mobs/players) that aren't exempt: cancel LivingUpdateEvent, and
 *    also sync their "last tick" position/rotation fields every tick so client-side
 *    interpolation renders them perfectly static (this replaces the render-side
 *    partial-tick-clamping mixins - a fully still entity needs no clamp).
 *  - Everything else (items, arrows, XP orbs, minecarts, ...): snapshot position/
 *    motion/rotation at the start of the tick and restore it at the end, undoing
 *    whatever vanilla did during the tick.
 *  - Block entities (furnaces, hoppers, brewing stands, ...): snapshot/restore their
 *    full NBT the same way, so smelting/brewing/hopper progress doesn't advance.
 *  - Weather and the day/night clock: snapshot/restore world time + rain/thunder time.
 *  - Random ticks (crop growth, leaf decay, ...): temporarily set randomTickSpeed to 0.
 *
 * Known simplifications vs. the original (documented in the README):
 *  - No true whole-engine tick-rate change for SLOW_MOTION / MATRIX / FAST_FORWARD;
 *    those are approximated with skipped/extra logic passes instead.
 *  - Client-only cosmetics (animated texture freezing, particle-physics freezing) are
 *    not ported, since they need client rendering internals with no Forge event hook
 *    in 1.12.2.
 */
@Mod.EventBusSubscriber(modid = TimeStopMod.MOD_ID)
public class ServerEventHandler {

    // entity id -> [posX, posY, posZ, motionX, motionY, motionZ, yaw, pitch]
    private static final Map<Integer, double[]> ENTITY_SNAPSHOT = new HashMap<>();
    private static final Map<BlockPos, NBTTagCompound> TILE_SNAPSHOT = new HashMap<>();
    private static final Set<BlockPos> TILE_SNAPSHOT_THIS_TICK = new HashSet<>();

    private static Long savedWorldTime = null;
    private static Integer savedRainTime = null;
    private static Integer savedThunderTime = null;
    private static Boolean savedRaining = null;
    private static Boolean savedThundering = null;
    private static String savedRandomTickSpeed = null;

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        WorldServer any = net.minecraftforge.fml.common.FMLCommonHandler.instance()
                .getMinecraftServerInstance().getWorld(0);
        TimeStopManager.serverTick(any);
    }

    @SubscribeEvent
    public static void onWorldTickStart(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        if (event.side != net.minecraftforge.fml.relauncher.Side.SERVER) return;
        if (!(event.world instanceof WorldServer)) return;
        WorldServer world = (WorldServer) event.world;

        boolean frozen = TimeStopManager.isTimeStopped(world) && TimeStopManager.getCurrentMode() == TimeMode.TIME_STOP;
        if (!frozen) return;

        applyRandomTickFreeze(world);
        snapshotWeatherAndTime(world);
        snapshotEntities(world);
        snapshotTileEntities(world);
    }

    @SubscribeEvent
    public static void onWorldTickEnd(TickEvent.WorldTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.side != net.minecraftforge.fml.relauncher.Side.SERVER) return;
        if (!(event.world instanceof WorldServer)) return;
        WorldServer world = (WorldServer) event.world;

        boolean frozen = TimeStopManager.isTimeStopped(world) && TimeStopManager.getCurrentMode() == TimeMode.TIME_STOP;
        if (frozen) {
            restoreWeatherAndTime(world);
            restoreEntities(world);
            restoreTileEntities(world);
        } else if (savedRandomTickSpeed != null) {
            // Time stop ended mid-tick somewhere else; make sure the gamerule gets restored.
            world.getGameRules().setOrCreateGameRule("randomTickSpeed", savedRandomTickSpeed);
            savedRandomTickSpeed = null;
        }
    }

    private static void applyRandomTickFreeze(WorldServer world) {
        if (savedRandomTickSpeed == null) {
            savedRandomTickSpeed = world.getGameRules().getString("randomTickSpeed");
            world.getGameRules().setOrCreateGameRule("randomTickSpeed", "0");
        }
    }

    private static void snapshotWeatherAndTime(WorldServer world) {
        if (savedWorldTime != null) return; // already holding a snapshot from an earlier tick
        WorldInfo info = world.getWorldInfo();
        savedWorldTime = world.getWorldTime();
        savedRainTime = info.getRainTime();
        savedThunderTime = info.getThunderTime();
        savedRaining = info.isRaining();
        savedThundering = info.isThundering();
    }

    private static void restoreWeatherAndTime(WorldServer world) {
        if (savedWorldTime == null) return;
        WorldInfo info = world.getWorldInfo();
        world.setWorldTime(savedWorldTime);
        info.setRainTime(savedRainTime);
        info.setThunderTime(savedThunderTime);
        info.setRaining(savedRaining);
        info.setThundering(savedThundering);
        savedWorldTime = null;
    }

    private static void snapshotEntities(WorldServer world) {
        for (Object o : world.loadedEntityList) {
            Entity entity = (Entity) o;
            if (entity instanceof EntityLivingBase) continue; // handled by LivingUpdateEvent instead
            ENTITY_SNAPSHOT.put(entity.getEntityId(), new double[]{
                    entity.posX, entity.posY, entity.posZ,
                    entity.motionX, entity.motionY, entity.motionZ,
                    entity.rotationYaw, entity.rotationPitch
            });

            if (entity instanceof IProjectile && !TimeStopManager.isSuspendedProjectile(entity.getUniqueID())) {
                TimeStopManager.registerSuspendedProjectile(entity, new Vec3d(entity.motionX, entity.motionY, entity.motionZ));
            }
        }
    }

    private static void restoreEntities(WorldServer world) {
        for (Object o : world.loadedEntityList) {
            Entity entity = (Entity) o;
            double[] snap = ENTITY_SNAPSHOT.get(entity.getEntityId());
            if (snap == null) continue;
            entity.posX = snap[0];
            entity.posY = snap[1];
            entity.posZ = snap[2];
            entity.motionX = snap[3];
            entity.motionY = snap[4];
            entity.motionZ = snap[5];
            entity.rotationYaw = (float) snap[6];
            entity.rotationPitch = (float) snap[7];
            entity.lastTickPosX = snap[0];
            entity.lastTickPosY = snap[1];
            entity.lastTickPosZ = snap[2];
            entity.prevRotationYaw = (float) snap[6];
            entity.prevRotationPitch = (float) snap[7];
            entity.fallDistance = 0;
        }
        ENTITY_SNAPSHOT.clear();
    }

    private static void snapshotTileEntities(WorldServer world) {
        TILE_SNAPSHOT_THIS_TICK.clear();
        for (Object o : world.loadedTileEntityList) {
            TileEntity te = (TileEntity) o;
            if (te.isInvalid()) continue;
            NBTTagCompound tag = new NBTTagCompound();
            te.writeToNBT(tag);
            TILE_SNAPSHOT.put(te.getPos(), tag);
            TILE_SNAPSHOT_THIS_TICK.add(te.getPos());
        }
    }

    private static void restoreTileEntities(WorldServer world) {
        for (Object o : world.loadedTileEntityList) {
            TileEntity te = (TileEntity) o;
            if (te.isInvalid()) continue;
            NBTTagCompound tag = TILE_SNAPSHOT.get(te.getPos());
            if (tag != null && TILE_SNAPSHOT_THIS_TICK.contains(te.getPos())) {
                te.readFromNBT(tag);
            }
        }
        TILE_SNAPSHOT.clear();
        TILE_SNAPSHOT_THIS_TICK.clear();
    }

    @SubscribeEvent
    public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        EntityLivingBase entity = event.getEntityLiving();
        World world = entity.world;
        if (world.isRemote) return;
        if (!TimeStopManager.isTimeStopped(world)) return;
        if (TimeStopManager.getCurrentMode() != TimeMode.TIME_STOP) return;
        if (TimeStopManager.isEntityExempt(entity)) return;

        // Keep interpolation fields in lockstep so the client renders this entity as
        // perfectly still instead of gliding for one more frame (replaces the render
        // partial-tick-clamp mixins from the original edition).
        entity.lastTickPosX = entity.posX;
        entity.lastTickPosY = entity.posY;
        entity.lastTickPosZ = entity.posZ;
        entity.prevRotationYaw = entity.rotationYaw;
        entity.prevRotationPitch = entity.rotationPitch;
        entity.motionX = 0;
        entity.motionY = 0;
        entity.motionZ = 0;
        entity.fallDistance = 0;

        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        EntityLivingBase victim = event.getEntityLiving();
        World world = victim.world;
        // Damage accumulation + hit suspension is exclusive to TIME_STOP mode; in the
        // other modes hits register immediately.
        if (world.isRemote) return;
        if (!TimeStopManager.isTimeStopped(world)) return;
        if (TimeStopManager.getCurrentMode() != TimeMode.TIME_STOP) return;
        if (TimeStopManager.isEntityExempt(victim)) return;

        TemporalDamageBuffer.recordHit(victim, event.getAmount(), event.getSource());
        event.setCanceled(true);
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (event.side != net.minecraftforge.fml.relauncher.Side.SERVER) return;
        EntityPlayer player = event.player;
        if (!TimeStopManager.isTimeStopped(player.world)) return;
        if (TimeStopManager.getCurrentMode() != TimeMode.TIME_STOP) return;
        if (!TimeStopManager.isEntityExempt(player)) return;

        LiquidWalking.apply(player);
    }
}
