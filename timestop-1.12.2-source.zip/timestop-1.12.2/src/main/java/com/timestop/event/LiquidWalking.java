package com.timestop.event;

import net.minecraft.block.BlockLiquid;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Porting note: the original LiquidBlockMixin made every liquid block return a fully
 * solid collision shape while TIME_STOP was active, which is a global, engine-level
 * change with no equivalent Forge event in 1.12.2 (there's no cancelable "get collision
 * box" hook for arbitrary blocks pre-1.13). This approximates the player-facing result
 * instead: an exempt (mobile) player standing in/above a frozen liquid column is kept
 * on its surface rather than sinking or swimming through it. It only affects players,
 * not general block collision, entity pathing, or thrown-item collision.
 */
final class LiquidWalking {
    private LiquidWalking() {
    }

    static void apply(EntityPlayer player) {
        World world = player.world;
        BlockPos feet = new BlockPos(player.posX, player.posY, player.posZ);
        if (!(world.getBlockState(feet).getBlock() instanceof BlockLiquid)) {
            return;
        }

        double surfaceY = feet.getY() + 1.0;
        if (player.posY < surfaceY) {
            player.posY = surfaceY;
            if (player.motionY < 0) {
                player.motionY = 0;
            }
            player.fallDistance = 0;
            player.onGround = true;
        }
    }
}
