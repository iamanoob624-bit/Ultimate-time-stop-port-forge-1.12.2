package com.timestop.command;

import com.timestop.core.TimeStopManager;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.WorldServer;

import javax.annotation.Nonnull;
import java.util.List;

/**
 * 1.12.2 has no Brigadier, so this is a single command with sub-arguments parsed
 * by hand: /timestop start [seconds] | stop | toggle [seconds] | exempt add|remove
 * <players> | status
 */
public class TimeStopCommand extends CommandBase {

    @Override
    public String getName() {
        return "timestop";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/timestop start [seconds] | stop | toggle [seconds] | exempt <add|remove> <players> | status";
    }

    @Override
    public int getRequiredPermissionLevel() {
        return 2;
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
        if (args.length == 0) {
            throw new WrongUsageException(getUsage(sender));
        }

        WorldServer level = server.getWorld(sender.getEntityWorld().provider.getDimension());

        switch (args[0]) {
            case "start": {
                int seconds = args.length > 1 ? parseInt(args[1], 1, 3600) : 0;
                startTimeStop(sender, level, seconds * 20);
                break;
            }
            case "stop": {
                stopTimeStop(sender, level);
                break;
            }
            case "toggle": {
                int seconds = args.length > 1 ? parseInt(args[1], 1, 3600) : 0;
                if (TimeStopManager.isTimeStopped(level)) {
                    stopTimeStop(sender, level);
                } else {
                    startTimeStop(sender, level, seconds * 20);
                }
                break;
            }
            case "exempt": {
                if (args.length < 3) throw new WrongUsageException(getUsage(sender));
                List<EntityPlayerMP> players = getPlayers(server, sender, args[2]);
                if ("add".equals(args[1])) {
                    for (EntityPlayerMP player : players) {
                        TimeStopManager.addExemptPlayer(player.getUniqueID());
                        sender.sendMessage(new TextComponentString("Added \u00A7e" + player.getName() + "\u00A7r to time stop exemption list."));
                    }
                } else if ("remove".equals(args[1])) {
                    for (EntityPlayerMP player : players) {
                        TimeStopManager.removeExemptPlayer(player.getUniqueID());
                        sender.sendMessage(new TextComponentString("Removed \u00A7e" + player.getName() + "\u00A7r from time stop exemption list."));
                    }
                } else {
                    throw new WrongUsageException(getUsage(sender));
                }
                break;
            }
            case "status": {
                boolean active = TimeStopManager.isGlobalTimeStopped();
                if (active) {
                    int remaining = TimeStopManager.getRemainingTicks();
                    String duration = remaining > 0 ? (remaining / 20) + "s remaining" : "Indefinite";
                    sender.sendMessage(new TextComponentString("\u00A76Time Stop Status: \u00A7aACTIVE \u00A7f(" + duration + ")"));
                } else {
                    sender.sendMessage(new TextComponentString("\u00A76Time Stop Status: \u00A7cINACTIVE"));
                }
                break;
            }
            default:
                throw new WrongUsageException(getUsage(sender));
        }
    }

    private void startTimeStop(ICommandSender sender, WorldServer level, int durationTicks) throws CommandException {
        if (TimeStopManager.isTimeStopped(level)) {
            throw new CommandException("Time is already stopped!");
        }
        EntityPlayerMP player = sender instanceof EntityPlayerMP ? (EntityPlayerMP) sender : null;
        TimeStopManager.startTimeStop(level, player, durationTicks);
        String durationStr = durationTicks > 0 ? (durationTicks / 20) + " seconds" : "indefinitely";
        sender.sendMessage(new TextComponentString("\u00A76Time stopped for " + durationStr + "."));
    }

    private void stopTimeStop(ICommandSender sender, WorldServer level) throws CommandException {
        if (!TimeStopManager.isTimeStopped(level)) {
            throw new CommandException("Time is not currently stopped!");
        }
        TimeStopManager.resumeTime(level);
        sender.sendMessage(new TextComponentString("\u00A7bTime resumed."));
    }

    @Override
    @Nonnull
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, net.minecraft.util.math.BlockPos targetPos) {
        if (args.length == 1) {
            return getListOfStringsMatchingLastWord(args, "start", "stop", "toggle", "exempt", "status");
        }
        if (args.length == 2 && "exempt".equals(args[0])) {
            return getListOfStringsMatchingLastWord(args, "add", "remove");
        }
        if (args.length == 3 && "exempt".equals(args[0])) {
            return getListOfStringsMatchingLastWord(args, server.getPlayerList().getOnlinePlayerNames());
        }
        return super.getTabCompletions(server, sender, args, targetPos);
    }
}
