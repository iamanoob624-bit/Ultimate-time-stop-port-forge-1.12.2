# Hardcore Time Stop — 1.12.2 Forge Port

Ported from the original 1.20.1 NeoForge + Mixin edition
(https://github.com/YatzCore/timestop-mod) to Minecraft 1.12.2 / Forge.

## Why this isn't a 1:1 Mixin port

The original mod works by using Mixin to inject directly into engine internals:
`MinecraftServer`'s tick loop, `ServerLevel`/`ClientLevel`'s entity ticking, render
interpolation, particle physics, and animated-texture cycling.

1.12.2 Forge has **no built-in Mixin support**. Getting Mixin working at all would mean
bundling a third-party bootstrap (e.g. a "Mixin Booter"-style coremod) as an extra
dependency, or writing and maintaining your own ASM coremod/tweaker. Rather than take
on that extra moving part, this port reimplements the same behavior with plain Forge
events, which is how time-manipulation mods were normally built in the 1.12.2 era.

**TIME_STOP — the flagship mode — is fully ported** using this approach:

| Original (Mixin)                                   | Port (Forge events)                                                        |
|------------------------------------------------------|-----------------------------------------------------------------------------|
| `ServerLevelMixin#tickNonPassenger` (freeze mobs)     | Cancel `LivingUpdateEvent` for non-exempt `EntityLivingBase`                |
| Freeze items/arrows/XP orbs/etc.                     | Snapshot position+motion+rotation at tick start, restore at tick end        |
| `LivingEntityMixin#hurt` (damage buffering)           | Cancel `LivingAttackEvent`, feed `TemporalDamageBuffer`                     |
| `ProjectileMixin#tick` (suspend arrows mid-air)       | Same snapshot/restore, plus explicit zero-velocity + no-gravity registration|
| `LevelMixin#tickBlockEntities`                        | Snapshot/restore each `TileEntity`'s full NBT each tick                     |
| `ServerLevelMixin#advanceWeatherCycle` / `tickTime`   | Snapshot/restore world time + rain/thunder time each tick                   |
| `ServerLevelMixin#tickChunk` (random ticks)           | Set the `randomTickSpeed` gamerule to 0 while frozen                        |
| Render partial-tick clamping (3 separate mixins)      | Not needed — a genuinely unmoving server-side entity has nothing to interpolate; syncing `lastTickPosX/Y/Z` etc. every tick keeps it perfectly still on the client |

## What's approximated, not ported 1:1

- **SLOW_MOTION / MATRIX / FAST_FORWARD**: the original mixed into `MinecraftServer`'s
  private tick-length constant for a true whole-engine speed change. That needs ASM
  and isn't attempted here. Instead:
  - SLOW_MOTION / MATRIX skip 3 out of every 4 world ticks for affected entities
    (`TimeStopManager.shouldExecuteSlowTick`), which gives a quarter-speed feel but with
    a slightly steppier motion than a true tick-rate change would.
  - FAST_FORWARD is scoped to world-state acceleration (random ticks via
    `randomTickSpeed`, and — if you wire it in — extra `TileEntity` update passes via
    `TimeStopManager.getFastForwardExtraPasses()`). It does **not** attempt to
    accelerate player/mob movement itself; doing that safely without desyncing
    client-authoritative player movement would need a different architecture.
  - MATRIX's original per-mechanic compensation (attack-cooldown recharge, item-use
    ticking, cooldown ticking) read and wrote `EntityLivingBase`'s private
    `attackStrengthTicker`/use-item fields directly via Mixin. 1.12.2 exposes no public
    API for that, and reflection into MCP/SRG-named private fields is fragile across
    setups, so it isn't included. MATRIX still slows the world and speeds up the
    exempt player via attribute modifiers (movement + attack speed); it just won't
    perfectly compensate every sub-system the original did.
- **"Solid liquid walking"**: the original made *every* liquid block return a fully
  solid collision shape globally while frozen (`LiquidBlockMixin`), a change with no
  arbitrary-block-collision event in 1.12.2 Forge. This port only keeps the
  time-stop-exempt player from sinking into liquid (`event/LiquidWalking.java`) — it's
  a player-convenience feature now, not a true global physics change. Mob pathing,
  thrown-item collision, etc. are unaffected.
- **Client-only cosmetics dropped**: animated-texture freezing (fire/lava mid-frame)
  and particle-physics freezing had no Forge event hook available in 1.12.2 without a
  coremod, so particles and animated textures will keep animating during a freeze.
  Everything else (the actual gameplay freeze) is unaffected.

## Things to double-check once you open this in an IDE

I don't have internet access in the environment I built this in, so I couldn't pull
the Forge 1.12.2 MDK/MCP mappings or actually compile against them — everything here
is written from what I know of the 1.12.2 API, not verified against a live decompile.
Skim for red squiggles on first import, especially:

- **`SoundEvents` field names** in `TimeStopManager`/`TemporalDamageBuffer`/items —
  several of the original's sounds (`BELL_BLOCK`, `CONDUIT_DEACTIVATE`,
  `WARDEN_HEARTBEAT`, `ENDER_EYE_DEATH`) don't exist pre-1.13/1.14/1.19 and were
  swapped for period-appropriate substitutes (`ENTITY_ENDERDRAGON_GROWL`,
  `ENTITY_GUARDIAN_AMBIENT`, `ENTITY_WITHER_AMBIENT`, `ENTITY_ENDEREYE_DEATH`). Feel
  free to swap in whatever fits — it's a cosmetic choice either way.
- `WorldInfo#getRainTime/setRainTime/getThunderTime/setThunderTime` and
  `DamageSource#getTrueSource()` in `TemporalDamageBuffer` — I'm confident these exist
  in 1.12.2 but haven't compiled against the real jar to be 100% sure of exact
  signatures.
- The client `player` field name on `Minecraft` (`mc.player`) — correct for 1.12.2 as
  far as I know, but if your mappings differ, your IDE will point you straight at it.

None of these are structural risks — worst case is a couple of one-line fixes once
Gradle pulls the real MCP mappings and your IDE shows actual errors instead of my
best-effort names.

## Building

This needs internet access (to pull Forge + MCP mappings) and a JDK 8, which the
sandbox I built this in doesn't have. On your own machine:

```bash
cd timestop-1.12.2
./gradlew setupDecompWorkspace   # first time only, slow
./gradlew build
```

The output jar lands in `build/libs/timestop-1.12.2-1.0.0.jar`. `./gradlew runClient`
launches a dev client with the mod loaded.

## Playing

- Craft a **Chronos Pocket Watch**: gold ingot / ender pearl / gold ingot ring around
  an ender pearl, clock on the bottom (see `assets/timestop/recipes/chronos_watch.json`
  — the original's amethyst shard + echo shard don't exist in 1.12.2, so this uses
  period-appropriate ingredients instead).
- Right-click to activate/stop your selected mode; sneak + right-click to cycle modes.
- **V** toggles time stop using whichever watch you're holding (same as the original).
- `/timestop start|stop|toggle [seconds]`, `/timestop exempt add|remove <players>`,
  `/timestop status` — same command surface as the original, rewritten without
  Brigadier since 1.12.2 doesn't have it.
- Creative players get the **Infinite Chronos Watch** (unlimited duration, zero
  cooldown) from the mod's creative tab.

## Package layout

```
com.timestop
├── TimeStopMod          - @Mod entry point, proxy wiring, command registration
├── core/                - TimeMode, TimeStopManager (server), ClientTimeStopManager,
│                          CooldownManager (1.12.2 has no built-in item-cooldown API)
├── combat/              - TemporalDamageBuffer (hit accumulation + discharge)
├── item/                - ModItems, ChronosWatchItem, CreativeWatchItem
├── network/             - ModMessages, TimeStopSyncPacket, ToggleTimeStopPacket
├── command/             - TimeStopCommand (CommandBase, no Brigadier)
├── event/               - ServerEventHandler (replaces every server-side Mixin),
│                          LiquidWalking
├── client/              - ClientEventHandler, ClientKeyBindings
└── proxy/               - CommonProxy / ClientProxy
```
